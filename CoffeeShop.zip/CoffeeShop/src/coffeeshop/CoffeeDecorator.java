/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coffeeshop;

/**
 *
 * @author akinb
 */
public class CoffeeDecorator implements Coffee{
    protected Coffee baseBeverage;
    
    public CoffeeDecorator (Coffee newBeverage){
        this.baseBeverage = newBeverage;
    }
    
    @Override
    public String getDescription() {
        return baseBeverage.getDescription();
    }
    @Override
    public double caloriteCount() {
        return baseBeverage.caloriteCount();
    }

    @Override
    public double calcCost() {
        return baseBeverage.calcCost();
    }

    @Override
    public double creationTime() {
        return baseBeverage.creationTime();
    }
}

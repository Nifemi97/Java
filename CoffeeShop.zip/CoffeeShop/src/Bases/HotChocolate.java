/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bases;

import coffeeshop.Coffee;

/**
 *
 * @author akinb
 */
public class HotChocolate implements Coffee{

    @Override
    public String getDescription() {
        return "Basic warm hot chocolate";
    }

    @Override
    public double caloriteCount() {
        return 200;
    }

    @Override
    public double calcCost() {
        return 3.50;
    }

    @Override
    public double creationTime() {
        return 3.50;
    }
    
}

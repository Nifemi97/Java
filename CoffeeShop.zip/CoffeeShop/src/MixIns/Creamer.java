/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MixIns;

import coffeeshop.Coffee;
import coffeeshop.CoffeeDecorator;

/**
 *
 * @author akinb
 */
public class Creamer extends CoffeeDecorator{

    public Creamer(Coffee newBeverage) {
        super(newBeverage);
    }
    
    @Override
    public String getDescription(){
        return baseBeverage.getDescription() + "Adding some creamer";
    }
    
    public double calorieCount(){
        return baseBeverage.caloriteCount() + 60;
    }
    
    @Override
    public double calcCost(){
        return baseBeverage.calcCost() + .30;
    }
    
    @Override
    public double creationTime(){
        return baseBeverage.creationTime() + 2.5;
    }
    
}

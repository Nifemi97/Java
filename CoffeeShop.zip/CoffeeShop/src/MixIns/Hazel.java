/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MixIns;

import coffeeshop.Coffee;
import coffeeshop.CoffeeDecorator;

/**
 *
 * @author akinb
 */
public class Hazel extends CoffeeDecorator{

    public Hazel(Coffee newBeverage) {
        super(newBeverage);
    }
    
    @Override
    public String getDescription(){
        return baseBeverage.getDescription() + "Adding some hazel";
    }
    
    public double calorieCount(){
        return baseBeverage.caloriteCount() + 15;
    }
    
    @Override
    public double calcCost(){
        return baseBeverage.calcCost() + .20;
    }
    
    @Override
    public double creationTime(){
        return baseBeverage.creationTime() + 1.5;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MixIns;

import coffeeshop.Coffee;
import coffeeshop.CoffeeDecorator;

/**
 *
 * @author akinb
 */
public class Milk extends CoffeeDecorator{

    public Milk(Coffee newBeverage) {
        super(newBeverage);
    }
    
       @Override
    public String getDescription(){
        return baseBeverage.getDescription() + "Adding some milk";
    }
    
    public double calorieCount(){
        return baseBeverage.caloriteCount() + 25;
    }
    
    @Override
    public double calcCost(){
        return baseBeverage.calcCost() + .15;
    }
    
    @Override
    public double creationTime(){
        return baseBeverage.creationTime() + 0;
    }
}

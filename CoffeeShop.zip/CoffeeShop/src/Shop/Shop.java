/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shop;

import Bases.DecaffinatedCoffee;
import Bases.HotChocolate;
import Bases.RoastCoffee;
import Bases.Tea;
import MixIns.Creamer;
import MixIns.Hazel;
import MixIns.Milk;
import MixIns.Soy;
import Toppings.CaramelDrizzle;
import Toppings.ChocolateShake;
import Toppings.MiniMarshmallows;
import Toppings.WhippedCream;
import coffeeshop.Coffee;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author akinb
 */
public class Shop {

    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
      //Coffee baseBeverage = new CoffeeDecorator();

        Coffee baseBeverage = null;
        System.out.println("Welcome to the beverage shop, would you like a beverage?");
        
        String answer = userInput.nextLine();
        while (answer.equalsIgnoreCase("yes")){
            if(answer.equalsIgnoreCase("yes")){
            String userMainMenu = "Select a beverage from the menu\n"
                + "1) Decafinated Coffee\n"
                + "2) Hot Choclate\n"
                + "3) Roast Coffee\n"
                + "4) Tea\n";
        int choice = getMenuSelection(userInput, userMainMenu, 1, 4);
         String decision = Integer.toString(choice);
         if(decision.equalsIgnoreCase("1")){
              baseBeverage = new DecaffinatedCoffee();
         }
         else if(decision.equalsIgnoreCase("2")){
              baseBeverage = new HotChocolate();
         }
         else if(decision.equalsIgnoreCase("3")){
              baseBeverage = new RoastCoffee();
         }
         else if(decision.equalsIgnoreCase("4")){
              baseBeverage = new Tea();
         }
         
               String toppingsMenu = "Select a topping\n"
                + "1) Caramel Drizzle\n"
                + "2) Chocolate Shake\n"
                + "3) Mini MArshmallows\n"
                + "4) Whipped Cream\n";
        int toppings = getToppingsSelection(userInput, toppingsMenu, 1, 4);
        String chosen = Integer.toString(toppings);
        
        if(chosen.equalsIgnoreCase("1")){
               // Coffee baseBeverage = null;
            baseBeverage = new CaramelDrizzle(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("2")){
            baseBeverage = new ChocolateShake(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("3")){
            baseBeverage = new MiniMarshmallows(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("4")){
            baseBeverage = new WhippedCream(baseBeverage);
        }
         
         String mixinsMenu = "Select a mix-ins\n"
                + "1) Creamer\n"
                + "2) Hazel\n"
                + "3) Milk\n"
                + "4) Soy\n";
        int mixins = getToppingsSelection(userInput, mixinsMenu, 1, 4);
        String mixes = Integer.toString(mixins);
        
        if(chosen.equalsIgnoreCase("1")){
               // Coffee baseBeverage = null;
            baseBeverage = new Creamer(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("2")){
            baseBeverage = new Hazel(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("3")){
            baseBeverage = new Milk(baseBeverage);
        }
        else if(chosen.equalsIgnoreCase("4")){
            baseBeverage = new Soy(baseBeverage);
        }
            System.out.println("Your order is: " + baseBeverage.getDescription());
            System.out.println("Cost: " + baseBeverage.calcCost());
            System.out.println("Calories: " + baseBeverage.caloriteCount());
            System.out.println("It will be ready in: " + baseBeverage.creationTime());
        
        }
        else if(answer.equalsIgnoreCase("no")){
            System.out.println("Goodbye");
        }
        }
        

    }

    public static int getMenuSelection(Scanner userInput, String menuText, int base, int max) {
        int choice = base - 1;
        while (choice < base || choice > max) {
            System.out.println(menuText);
            try {
                choice = userInput.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please enter a NUMBER between " + base + " and " + max);
            }
        }
        userInput.nextLine();
        return choice;
    }
    
   
    
    public static int getToppingsSelection(Scanner userInput, String menuText, int base, int max) {
        int choice = base - 1;
        while (choice < base || choice > max) {
            System.out.println(menuText);
            try {
                choice = userInput.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please enter a NUMBER between " + base + " and " + max);
            }
        }
        userInput.nextLine();
        return choice;
    }
    
     public static int getMixInsSelection(Scanner userInput, String menuText, int base, int max) {
        int choice = base - 1;
        while (choice < base || choice > max) {
            System.out.println(menuText);
            try {
                choice = userInput.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please enter a NUMBER between " + base + " and " + max);
            }
        }
        userInput.nextLine();
        return choice;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Toppings;

import coffeeshop.Coffee;
import coffeeshop.CoffeeDecorator;

/**
 *
 * @author akinb
 */
public class MiniMarshmallows extends CoffeeDecorator{

    public MiniMarshmallows(Coffee newBeverage) {
        super(newBeverage);
    }
    
    @Override
    public String getDescription(){
        return baseBeverage.getDescription() + "topped with mini marshmallows";
    }
    
    public double calorieCount(){
        return baseBeverage.caloriteCount() + 30;
    }
    
    @Override
    public double calcCost(){
        return baseBeverage.calcCost() + .50;
    }
    
    @Override
    public double creationTime(){
        return baseBeverage.creationTime() + 0;
    }
    
}
